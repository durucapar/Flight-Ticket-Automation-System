﻿using Microsoft.AspNetCore.Mvc;
using TicketAutomationProject.Models;
using TicketAutomationProject.Utility;

namespace TicketAutomationProject.Controllers
{
    public class AirportController : Controller
    {
        private readonly ApplicationDbContext _applicationDbContext;
        public AirportController(ApplicationDbContext context)
        {
            _applicationDbContext = context;
        }
        public IActionResult Index()
        {
            List<Airport> objAirportList = _applicationDbContext.Airports.ToList();

            return View(objAirportList);
        }

        public IActionResult Select(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            List<Flight> objFlightList = _applicationDbContext.Flights.ToList();
            List<Flight> newFlightList = new List<Flight>();


            for (int j = 0; j < objFlightList.Count; j++)
            {

                if (objFlightList[j].AirportCode == id)
                {
                    newFlightList.Add(objFlightList[j]);
                }

            }

            return View(newFlightList);
        }

    

    }
}
