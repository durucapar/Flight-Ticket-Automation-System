﻿using Microsoft.AspNetCore.Mvc;
using TicketAutomationProject.Models;
using TicketAutomationProject.Utility;

namespace TicketAutomationProject.Controllers
{
    public class CompanyController : Controller
    {
        private readonly ApplicationDbContext _applicationDbContext;
        public CompanyController(ApplicationDbContext context)
        {
            _applicationDbContext = context;
        }
        public IActionResult Index()
        {
            List<Company> objCompanyList = _applicationDbContext.Company.ToList();
            return View(objCompanyList);
        }
    }
}
