﻿using Microsoft.AspNetCore.Mvc;
using TicketAutomationProject.Models;
using TicketAutomationProject.Utility;

namespace TicketAutomationProject.Controllers
{
    public class PassengerController : Controller
    {
        private readonly ApplicationDbContext _applicationDbContext;
        public PassengerController(ApplicationDbContext context)
        {
            _applicationDbContext = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Payment()
        {
            return View();
        }

        public IActionResult ChooseClass()
        {
            List<SeatClass> objSeatClassList = _applicationDbContext.SeatClasses.ToList();

            return View(objSeatClassList);
        }


        public IActionResult Seat(int? id)
        {
            List<Seat> objSeatList = _applicationDbContext.Seats.ToList();
            List<Seat> newSeatList = new();


            for (int j = 0; j < objSeatList.Count; j++)
            {

                if (objSeatList[j].SeatClass == id)
                {
                    newSeatList.Add(objSeatList[j]);
                }

            }

            return View(newSeatList);
        }

        public IActionResult ChooseSeat(int id)
        {
            List<Seat> objSeatList = _applicationDbContext.Seats.ToList();
            ChosenSeat cs= new ChosenSeat();
            cs.SeatID = id;

            for (int j = 0; j < objSeatList.Count; j++)
            {
                if (objSeatList[j].SeatID == id)
                {
                    cs.SeatNo = objSeatList[j].SeatNo;
                    objSeatList[j].IsEmpty = 1;
                    _applicationDbContext.Seats.Update(objSeatList[j]);
                    _applicationDbContext.SaveChanges();
                    break;
                }

            }
            _applicationDbContext.ChosenSeats.Add(cs);
            _applicationDbContext.SaveChanges();


            return RedirectToAction("Payment", "Ticket");
        }

        public IActionResult Book(int id)
        {
            List<ChosenFlight> objChosenFlightList = _applicationDbContext.ChosenFlights.ToList();
            ChosenFlight chosenFlight = new();
            chosenFlight.ChosenFlightId = id;
            _applicationDbContext.ChosenFlights.Add(chosenFlight);
            _applicationDbContext.SaveChanges();

            return View();
        }

        [HttpPost]

        public IActionResult Book(Passenger passenger)
        {
            _applicationDbContext.Passengers.Add(passenger);
            _applicationDbContext.SaveChanges();
            return RedirectToAction("ChooseClass", "Passenger");
        }



    }
}
