﻿using Microsoft.AspNetCore.Mvc;
using TicketAutomationProject.Models;
using TicketAutomationProject.Utility;

namespace TicketAutomationProject.Controllers
{
    public class SeatController : Controller
    {

        private readonly ApplicationDbContext _applicationDbContext;
        public SeatController(ApplicationDbContext context)
        {
            _applicationDbContext = context;
        }
        public IActionResult Index()
        {
            List<Seat> objSeatList = _applicationDbContext.Seats.ToList();

            return View(objSeatList);
        }
    }
}
