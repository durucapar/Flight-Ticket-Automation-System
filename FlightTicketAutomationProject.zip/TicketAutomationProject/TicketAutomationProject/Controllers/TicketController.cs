﻿using Microsoft.AspNetCore.Mvc;
using TicketAutomationProject.Models;
using TicketAutomationProject.Utility;

namespace TicketAutomationProject.Controllers
{
    public class TicketController : Controller
    {
        private readonly ApplicationDbContext _applicationDbContext;
        public TicketController(ApplicationDbContext context)
        {
            _applicationDbContext = context;
        }
        public IActionResult Index()
        {
            Ticket ticket = new Ticket();
            List<Ticket> objTicketList = _applicationDbContext.Tickets.ToList();
            List<Plane> objPlaneList = _applicationDbContext.Planes.ToList();
            List<Flight> objFlightList = _applicationDbContext.Flights.ToList();
            List<Passenger> objPassengerList = _applicationDbContext.Passengers.ToList();
            List<Seat> objSeatList = _applicationDbContext.Seats.ToList();
            List<SeatClass> objSeatClassList = _applicationDbContext.SeatClasses.ToList();
            List<ChosenFlight> chosenFlights = _applicationDbContext.ChosenFlights.ToList();
            List<ChosenSeat> chosenSeats = _applicationDbContext.ChosenSeats.ToList();

            ticket.TicketID = objTicketList.Count + 1;

            for (int i = 0; i < objFlightList.Count; i++)
            {
                if (objFlightList[i].FlightID== chosenFlights[chosenFlights.Count-1].ChosenFlightId)
                {
                    ticket.FlightDate = objFlightList[i].FlightDate;
                    ticket.DepartureTime = objFlightList[i].FlightTime;
                    ticket.PlaceOfDeparture= objFlightList[i].PlaceOfDeparture;
                    ticket.PlaceOfArrival = objFlightList[i].PlaceOfArrival;

                    for (int j = 0; j < objPlaneList.Count; j++)
                    {
                        if (objFlightList[i].FlightID == objPlaneList[j].FlightID)
                        {
                            ticket.PlaneRegistrationCode = objPlaneList[j].RegistrationCode;
                            ticket.FlightCode = objPlaneList[j].FlightCode;
                            break;
                        }
                    }break;
                }                
            }
            
                ticket.SeatNo =chosenSeats[chosenSeats.Count-1].SeatNo;
 
            for (int i = 0; i < objSeatList.Count; i++)
            {
                if (objSeatList[i].IsEmpty == 1)
                {
                   
                    for (int j = 0; j < objSeatClassList.Count; j++)
                    {
                        if (objSeatList[i].SeatClass == objSeatClassList[j].ClassID)
                        {
                            ticket.TicketPrice = objSeatClassList[j].ClassPrice;
                            ticket.ClassType = objSeatClassList[j].ClassType;
                            break;
                        }

                    }break;
                }
               
            }

            ticket.PassengerID = objPassengerList[objPassengerList.Count - 1].PassengerID;
            ticket.PassengerName = objPassengerList[objPassengerList.Count - 1].PassengerName;

            _applicationDbContext.Tickets.Add(ticket);
            _applicationDbContext.SaveChanges();

            List<Ticket> newTicketList = new();
            newTicketList.Add(ticket);

            return View(newTicketList);
        }

        public IActionResult Payment()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Payment(int a)
        {

            return RedirectToAction("Index", "Ticket");
        }
    }
}
