﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Airport
    {
        [Key] public int AirportID { get; set; }
        [Required] public string AirportName { get; set; }
        [Required] public string AirportCity { get; set; }

    }
}
