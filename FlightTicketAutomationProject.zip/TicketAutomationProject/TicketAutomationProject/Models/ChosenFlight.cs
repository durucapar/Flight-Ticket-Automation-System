﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class ChosenFlight
    {
        [Key] public int Id { get; set; }
        [Required] public int ChosenFlightId { get; set; }
    }
}
