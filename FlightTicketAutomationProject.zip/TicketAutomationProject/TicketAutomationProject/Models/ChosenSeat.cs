﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class ChosenSeat
    {
        [Key] public int SeatID { get; set; }
        [Required] public string SeatNo { get; set; }
    }
}
