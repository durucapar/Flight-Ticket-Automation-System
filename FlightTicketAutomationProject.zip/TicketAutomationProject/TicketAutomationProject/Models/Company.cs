﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Company
    {
        [Key] public string CompanyName { get; set; }
        [Required] public string CustomerServicesDialNum { get; set; }
    }
}
