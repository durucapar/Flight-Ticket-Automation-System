﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Flight
    {
        [Key] public int FlightID { get; set; }
        [Required] public string PlaceOfDeparture { get; set; }
        [Required] public string PlaceOfArrival { get; set; }
        [Required] public string FlightDate { get; set; }
        [Required] public string FlightTime { get; set; }
        [Required] public string GateCode { get; set; }
        [Required] public int AirportCode { get; set; }


    }
}
