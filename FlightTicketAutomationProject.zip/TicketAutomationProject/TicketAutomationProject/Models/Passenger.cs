﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Passenger
    {
        [Key] public string PassengerID { get; set; }
        [Required] public string PassengerName { get; set; }
        [Required] public string EmailAddress { get; set; }
        [Required] public int PhoneNumber { get; set; }

    }
}
