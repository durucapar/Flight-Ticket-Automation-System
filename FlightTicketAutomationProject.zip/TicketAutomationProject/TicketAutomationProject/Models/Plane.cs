﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Plane
    {
        [Key] public string RegistrationCode { get; set; }
        [Required] public string FlightCode { get; set; }
        [Required] public int FlightID { get; set; }

    }
}
