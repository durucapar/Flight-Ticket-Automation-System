﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Seat
    {
        [Key] public int SeatID { get; set; }
        [Required] public string SeatNo { get; set; }
        [Required] public int SeatClass { get; set; }
        [Required] public int IsEmpty { get; set; }

    }
}
