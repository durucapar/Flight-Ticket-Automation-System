﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class SeatClass
    {
        [Key] public int ClassID { get; set; }
        [Required] public string ClassType { get; set; }
        [Required] public int ClassPrice { get; set; }

    }
}
