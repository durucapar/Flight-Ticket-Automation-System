﻿using System.ComponentModel.DataAnnotations;

namespace TicketAutomationProject.Models
{
    public class Ticket
    {
        [Key] public int TicketID { get; set; }
        [Required] public string FlightDate { get; set; }
        [Required] public string DepartureTime { get; set; }
        [Required] public int TicketPrice { get; set; }
        [Required] public string SeatNo { get; set; }
        [Required] public string PlaneRegistrationCode { get; set; }
        [Required] public string FlightCode { get; set; }
        [Required] public string PassengerID { get; set; }
        [Required] public string PassengerName { get; set; }
        [Required] public string ClassType { get; set; }
        [Required] public string PlaceOfDeparture { get; set; }
        [Required] public string PlaceOfArrival { get; set; }

    }
}
