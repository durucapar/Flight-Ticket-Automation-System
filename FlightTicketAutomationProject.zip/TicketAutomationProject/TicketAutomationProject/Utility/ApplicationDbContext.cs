﻿using Microsoft.EntityFrameworkCore;
using TicketAutomationProject.Models;

namespace TicketAutomationProject.Utility
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Airport> Airports { get; set; }
        public DbSet<Company> Company { get; set; }
        public DbSet<Flight> Flights { get; set; }
        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<Plane> Planes { get; set; }
        public DbSet<SeatClass> SeatClasses { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<ChosenSeat> ChosenSeats { get; set; }
        public DbSet<ChosenFlight> ChosenFlights { get; set; }
        public DbSet<Seat> Seats { get; set; }

    }
}
